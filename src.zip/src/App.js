
import './App.css';
import AffichePlante from "./pages/plante"


function App() {
  return (
    <AffichePlante/>
  );
}

export default App;
