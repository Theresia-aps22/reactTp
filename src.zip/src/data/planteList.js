import image from "../assets/image/plante1.jpg"

const planteList = [
    {
        id:"aaa",
        nom:"Dahlia",
        categorie:"classique",
        lumiere:2,
        eau:2,
        photo:image
    },
    {
        id:"aac",
        nom:"Vanille",
        categorie:"classique",
        lumiere:1,
        eau:2,
        photo:image
    },
    {
        id:"aad",
        nom:"Rose",
        categorie:"plante graisse",
        lumiere:3,
        eau:1,
        photo:image
    },
    {
        id:"aae",
        nom:"Inc",
        categorie:"exterieur",
        lumiere:2,
        eau:2,
        photo:image
    },

]

export default planteList