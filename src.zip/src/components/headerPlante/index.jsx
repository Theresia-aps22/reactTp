import "../../assets/css/headerPlante.css"
export default function HeaderPlante(){
    return(
        <div className="containerPlante">
            <div className="divHeaderPlante">
                <p className="titleHeader">🍃 PLANTES</p>
            </div>
            <div className="ligne"></div>
        </div>
    )
}